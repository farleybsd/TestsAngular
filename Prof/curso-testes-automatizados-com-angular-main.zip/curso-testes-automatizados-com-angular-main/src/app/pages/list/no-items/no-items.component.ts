import { Component } from '@angular/core';

@Component({
  selector: 'app-no-items',
  standalone: true,
  imports: [],
  templateUrl: './no-items.component.html',
})
export class NoItemsComponent {

}
