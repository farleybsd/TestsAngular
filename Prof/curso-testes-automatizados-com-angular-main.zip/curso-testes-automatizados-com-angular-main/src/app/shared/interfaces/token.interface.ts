export interface TokenResponse {
  token: string;
}
