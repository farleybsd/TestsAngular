export function setAuthToken() {
  window.localStorage.setItem('auth-token', 'fake-jwt-token');
}
