export function clearStorage() {
  window.localStorage.clear();
}
