import { Component } from '@angular/core';

@Component({
  selector: 'app-header',
  standalone: true,
  template: '',
})
export class FakeHeaderComponent {}
